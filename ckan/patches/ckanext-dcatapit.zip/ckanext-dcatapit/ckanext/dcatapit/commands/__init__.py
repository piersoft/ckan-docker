
class DataException(ValueError):
    pass

class ConfigException(ValueError):
    pass